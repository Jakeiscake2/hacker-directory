import pygame
import time
class Player():
	x_speed =  0
	y_speed = 0
	sprites = []
	
	def __init__(self,x,y,sprites):
		if len(sprites)==6:
			self.sprites=sprites
			self.image=pygame.Surface([20,20])
			self.image = sprites[0]
			self.rect = self.image.get_rect()
			self.rect.x = x
			self.rect.y = y
	def updatePlayer(self,x_change,y_change):
		self.x_speed += x_change - (abs(self.y_speed)/self.y_speed)*0.1
		self.y_speed += y_change - (abs(self.y_speed)/self.y_speed)*0.1
		if abs(self.change_x) > 10:
			self.change_x = 10*abs(self.change_x)/self.change_x
		if abs(self.change_y) > 10:
			self.change_y = 10*abs(self.change_y)/self.change_y

		self.rect.x += self.x_speed
		self.rect.y += self.y_speed

		if(self.downpressed):
			self.image = self.sprites[1]
		elif(self.x_speed>0):
			self.image = self.sprites[2] 
		elif(self.x_speed<0):
			self.image = self.sprites[3] 
		else:
			self.image = self.sprites[0]
	def collision(self,other_sprites):
		hit_list = pygame.sprite.spritecollide(self,other_sprites,False)
		
#sprites = [normal, down, right, left]